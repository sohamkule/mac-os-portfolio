const social = {
    github: {
        name: 'GitHub',
        url: 'https://github.com/sohamkule',
        username: 'sohamkule',
    },

    linkedin: {
        name: 'LinkedIn',
        url: 'https://www.linkedin.com/in/soham-kule-188062346/',
        username: 'soham kule',
    },

    instagram: {
        name: 'Instagram',
        url: 'https://www.instagram.com/soham_kule/',
        username: 'soham_kule',
    },
}

export default social