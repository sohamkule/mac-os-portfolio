import './dock.scss'

const Dock = ({ setWindowsState }) => {
    const openWindow = (windowName) => {
        setWindowsState(state => ({
            ...state,
            [windowName]: true
        }))
    }

    const openExternal = (url) => {
        window.open(url, '_blank', 'noopener,noreferrer')
    }

    const openMail = () => {
        window.location.href = 'mailto:sohamkule18@gmail.com'
    }

    return (
        <footer className="dock" aria-label="Application Dock">

            <button
                type="button"
                onClick={() => openWindow('github')}
                className="icon github"
                aria-label="Open GitHub"
                title="GitHub"
            >
                <img
                    src="/doc-icons/github.svg"
                    alt=""
                    aria-hidden="true"
                />
            </button>

            <button
                type="button"
                onClick={() => openWindow('note')}
                className="icon note"
                aria-label="Open Notes"
                title="Notes"
            >
                <img
                    src="/doc-icons/note.svg"
                    alt=""
                    aria-hidden="true"
                />
            </button>

            <button
                type="button"
                onClick={() => openWindow('resume')}
                className="icon pdf"
                aria-label="Open Resume"
                title="Resume"
            >
                <img
                    src="/doc-icons/pdf.svg"
                    alt=""
                    aria-hidden="true"
                />
            </button>

            <button
                type="button"
                onClick={() => openExternal('https://calendar.google.com/')}
                className="icon calender"
                aria-label="Open Google Calendar"
                title="Calendar"
            >
                <img
                    src="/doc-icons/calender.svg"
                    alt=""
                    aria-hidden="true"
                />
            </button>

            <button
                type="button"
                onClick={() => openWindow('spotify')}
                className="icon spotify"
                aria-label="Open Spotify"
                title="Spotify"
            >
                <img
                    src="/doc-icons/spotify.svg"
                    alt=""
                    aria-hidden="true"
                />
            </button>

            <button
                type="button"
                onClick={openMail}
                className="icon mail"
                aria-label="Send email"
                title="Email"
            >
                <img
                    src="/doc-icons/mail.svg"
                    alt=""
                    aria-hidden="true"
                />
            </button>

            <button
                type="button"
                onClick={() => openExternal(
                    'https://www.linkedin.com/in/soham-kule-188062346/'
                )}
                className="icon link"
                aria-label="Open LinkedIn"
                title="LinkedIn"
            >
                <img
                    src="/doc-icons/link.svg"
                    alt=""
                    aria-hidden="true"
                />
            </button>

            <button
                type="button"
                onClick={() => openWindow('cli')}
                className="icon cli"
                aria-label="Open Terminal"
                title="Terminal"
            >
                <img
                    src="/doc-icons/cli.svg"
                    alt=""
                    aria-hidden="true"
                />
            </button>

        </footer>
    )
}

export default Dock