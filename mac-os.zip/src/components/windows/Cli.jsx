import MacWindow from './MacWindow'

import './cli.scss'

import pkg from 'react-console-emulator'

const Terminal = pkg.Terminal || pkg.default || pkg

const availableCommands = `Available commands:
  help       Show all available commands
  about      About this portfolio
  projects   View featured projects
  skills     Show tech stack and skills
  experience Work experience overview
  contact    Contact details and social links
  resume     Portfolio resume info`

const Cli = ({ windowName , windowsState , setWindowsState }) => {
    return (
        <MacWindow windowName = {windowName} windowsState={windowsState} setWindowsState = {setWindowsState} >
            <div className="cli-window">
                <Terminal
                    noDefaults
                    commands={{
                        help: {
                            description: 'List all available commands.',
                            usage: 'help',
                            fn: () => availableCommands
                        },
                        about: {
                            description: 'Learn more about this portfolio.',
                            usage: 'about',
                            fn: () => 'Hi, I am Soham Kule — a passionate frontend developer building modern, responsive web experiences with React and clean UI design.'
                        },
                        projects: {
                            description: 'Show featured projects.',
                            usage: 'projects',
                            fn: () => 'Featured projects:\n- macOS Portfolio\n- TeamSync\n- Custom UI Experiments'
                        },
                        skills: {
                            description: 'Show technologies and skills.',
                            usage: 'skills',
                            fn: () => 'Skills: React, JavaScript, HTML, CSS, SCSS, Vite, UI/UX, responsive design, frontend architecture.'
                        },
                        experience: {
                            description: 'View experience overview.',
                            usage: 'experience',
                            fn: () => 'Experience:\n- Frontend Developer\n- UI Engineering\n- Building polished product interfaces and interactive experiences.'
                        },
                        contact: {
                            description: 'Display contact information.',
                            usage: 'contact',
                            fn: () => 'Email: hello@example.com\nLinkedIn: linkedin.com/in/sohamkule\nGitHub: github.com/sohamkule'
                        },
                        resume: {
                            description: 'Show resume information.',
                            usage: 'resume',
                            fn: () => 'Resume is available on request. Reach out for a copy or a quick collaboration call.'
                        }
                    }}
                    welcomeMessage={'Welcome to Soham Kule’s portfolio terminal!\nType "help" to see all available commands.'}
                    promptLabel={'sohamKule@portfolio:~$'}
                    promptLabelStyle={{ color: '#00ff00' }}
                />
            </div>
        </MacWindow>
    )
}

export default Cli