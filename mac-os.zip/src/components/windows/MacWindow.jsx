import { Rnd } from 'react-rnd'
import './window.scss'

const MacWindow = ({
    children,
    width = '40vw',
    height = '40vh',
    windowName,
    setWindowsState
}) => {

    const closeWindow = () => {
        setWindowsState(state => ({
            ...state,
            [windowName]: false
        }))
    }

    return (
        <div>
            <Rnd
                default={{
                    width,
                    height,
                    x: 300,
                    y: 200
                }}
            >
                <div className="window">

                    <div className="nav">

                        <div className="dots">

                            <button
                                type="button"
                                onClick={closeWindow}
                                className="dot red"
                                aria-label="Close window"
                                title="Close"
                            />

                            <button
                                type="button"
                                className="dot yellow"
                                aria-label="Minimize window"
                                title="Minimize"
                            />

                            <button
                                type="button"
                                className="dot green"
                                aria-label="Maximize window"
                                title="Maximize"
                            />

                        </div>

                        <div className="title">
                            <p>sohamkule - zsh</p>
                        </div>

                    </div>

                    <div className="main-content">
                        {children}
                    </div>

                </div>
            </Rnd>
        </div>
    )
}

export default MacWindow